package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.SoundPool
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

enum class SoundEffect {
    TAP,                  // Google Keyboard (Gboard) letter typing key click sound
    OPTION_SELECT,        // Joyful crystal bell ding (A5 -> E6)
    NAV_NEXT,             // Cheerful rising 3-tone arpeggio (E5 -> A5 -> C#6)
    NAV_PREV,             // Gentle descending 3-tone chime (C#6 -> A5 -> E5)
    TEST_SUBMIT_LONG,     // Grand triumphant victory celebration fanfare (~2.2s)
    LOGIN_SUCCESS,        // Uplifting harmonious major chord
    REFRESH,              // Sparkling breeze cascade chime
    TAB_SWITCH,           // Crisp acoustic woodblock tick
    ERROR_OR_DELETE,      // Polite warm marimba double-tap
    SWITCH_TOGGLE         // Sweet bouncy double-pop
}

/**
 * SoundManager provides joyful, crystal-clear, melodic sound effects for all app interactions.
 * - Uses native Android SoundPool for zero-latency, high-fidelity, hardware-mixed audio.
 * - Peak 16-bit PCM amplitude normalized to ~27000 (well-balanced, clear, loud enough to hear clearly).
 * - Tied directly to USAGE_MEDIA so phone volume buttons adjust volume intuitively.
 * - Generates pleasant harmonic acoustic instruments (crystal chimes, marimba, water droplet).
 * - Includes a glorious 2.2-second victory celebration chime for Test Submit.
 * - 1-Click Master Mute / Unmute with reactive StateFlow and persistent preferences.
 */
object SoundManager {
    private const val PREFS_NAME = "test_mitra_sound_prefs"
    private const val KEY_MUTED = "is_sound_muted"
    private const val SAMPLE_RATE = 44100

    private val _isMutedState = MutableStateFlow(false)
    val isMutedState: StateFlow<Boolean> = _isMutedState.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private var soundPool: SoundPool? = null
    private val soundPoolMap = ConcurrentHashMap<SoundEffect, Int>()
    private val loadedSoundIds = Collections.synchronizedSet(HashSet<Int>())
    private val pcmCache = ConcurrentHashMap<SoundEffect, ShortArray>()

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _isMutedState.value = prefs.getBoolean(KEY_MUTED, false)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val pool = SoundPool.Builder()
            .setMaxStreams(10)
            .setAudioAttributes(audioAttributes)
            .build()

        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSoundIds.add(sampleId)
            }
        }
        soundPool = pool

        // Preload sounds in background IO
        scope.launch(Dispatchers.IO) {
            try {
                val soundDir = File(context.cacheDir, "testmitra_audio_v5")
                if (!soundDir.exists()) soundDir.mkdirs()

                SoundEffect.entries.forEach { effect ->
                    val pcm = generateSound(effect)
                    pcmCache[effect] = pcm

                    val wavFile = File(soundDir, "${effect.name.lowercase()}.wav")
                    if (!wavFile.exists() || wavFile.length() == 0L) {
                        val wavBytes = pcmToWav(pcm, SAMPLE_RATE)
                        FileOutputStream(wavFile).use { it.write(wavBytes) }
                    }
                    val soundId = pool.load(wavFile.absolutePath, 1)
                    soundPoolMap[effect] = soundId
                }
            } catch (_: Exception) {
                // Preload fallback to dynamic AudioTrack
            }
        }
    }

    fun toggleMute(context: Context) {
        val newMuted = !_isMutedState.value
        _isMutedState.value = newMuted
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_MUTED, newMuted).apply()

        // If unmuting, give a pleasant confirmation click
        if (!newMuted) {
            playSound(SoundEffect.TAP)
        }
    }

    fun setMuted(muted: Boolean, context: Context) {
        if (_isMutedState.value == muted) return
        _isMutedState.value = muted
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_MUTED, muted).apply()
    }

    fun isMuted(): Boolean = _isMutedState.value

    fun playSound(effect: SoundEffect) {
        if (_isMutedState.value) return

        val pool = soundPool
        val soundId = soundPoolMap[effect]

        if (pool != null && soundId != null && loadedSoundIds.contains(soundId)) {
            // Volume 1.0f routes through Media Volume slider
            pool.play(soundId, 1.0f, 1.0f, 1, 0, 1.0f)
        } else {
            // Immediate AudioTrack fallback
            scope.launch {
                val pcm = pcmCache[effect] ?: generateSound(effect).also { pcmCache[effect] = it }
                playPcmFallback(pcm)
            }
        }
    }

    private fun playPcmFallback(buffer: ShortArray) {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            val track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()

            val durationMs = (buffer.size * 1000L) / SAMPLE_RATE
            scope.launch {
                delay(durationMs + 60)
                try {
                    track.stop()
                    track.release()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    // ---------------- Waveform Synthesizers (Rich, Melodic, High Dynamic Range) ----------------

    private fun generateSound(effect: SoundEffect): ShortArray {
        return when (effect) {
            SoundEffect.TAP -> generateTapSound()
            SoundEffect.OPTION_SELECT -> generateOptionSelectSound()
            SoundEffect.NAV_NEXT -> generateNavNextSound()
            SoundEffect.NAV_PREV -> generateNavPrevSound()
            SoundEffect.TEST_SUBMIT_LONG -> generateTestSubmitLongSound()
            SoundEffect.LOGIN_SUCCESS -> generateLoginSuccessSound()
            SoundEffect.REFRESH -> generateRefreshSound()
            SoundEffect.TAB_SWITCH -> generateTabSwitchSound()
            SoundEffect.ERROR_OR_DELETE -> generateErrorOrDeleteSound()
            SoundEffect.SWITCH_TOGGLE -> generateSwitchToggleSound()
        }
    }

    /**
     * Delicate, thin, crisp keypress click sound (~12ms).
     * Tailored to be light, crisp, and subtle ("patalo avaj") without any heavy
     * bass thump or thick resonance, exactly like the gentle tactile key click
     * of Google Keyboard (Gboard).
     */
    private fun generateTapSound(): ShortArray {
        val durationMs = 12
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 15000.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples

            // Instant sharp micro-attack (0.15ms)
            val attack = min(1.0, i.toDouble() / (SAMPLE_RATE * 0.00015))
            // Rapid steep exponential decay for a crisp, light, thin tick
            val decay = exp(-progress * 22.0)
            val envelope = attack * decay

            // High-frequency delicate snap: 4200Hz dropping swiftly to 1800Hz
            val snapFreq = 4200.0 * exp(-progress * 20.0) + 1800.0
            val snapTone = sin(2.0 * PI * snapFreq * t)

            // Very subtle high transient sparkle at 5400Hz (adds delicate airiness without bass)
            val airyTone = sin(2.0 * PI * 5400.0 * t) * 0.25 * exp(-progress * 35.0)

            // Combined thin, delicate click with zero low-frequency bass body
            val sample = (snapTone * 0.75 + airyTone) * envelope
            buffer[i] = (sample * maxAmp).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    /**
     * Delightful crystal bell ding for MCQ option selection (160ms).
     * Two harmonically connected bell strikes: G5 (784Hz) then C6 (1046.5Hz) with sparkling chime ring.
     * Makes answering questions feel super rewarding and fun!
     */
    private fun generateOptionSelectSound(): ShortArray {
        val durationMs = 160
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 27000.0

        val notes = listOf(
            Pair(0, 783.99),    // G5 at 0ms
            Pair(40, 1046.50)   // C6 at 40ms
        )

        for (i in 0 until numSamples) {
            val currentMs = (i * 1000) / SAMPLE_RATE
            var sampleSum = 0.0

            for ((startMs, freq) in notes) {
                if (currentMs >= startMs) {
                    val noteSampleIndex = i - (startMs * SAMPLE_RATE / 1000)
                    val noteTotalSamples = ((durationMs - startMs) * SAMPLE_RATE) / 1000
                    val noteProgress = noteSampleIndex.toDouble() / noteTotalSamples
                    val t = noteSampleIndex.toDouble() / SAMPLE_RATE

                    val attack = min(1.0, noteSampleIndex.toDouble() / (SAMPLE_RATE * 0.005))
                    val decay = exp(-noteProgress * 4.5)
                    val envelope = attack * decay

                    // Crystal glass bell overtones (fundamental + 2.4x chime partial)
                    val tone = 0.70 * sin(2.0 * PI * freq * t) + 0.30 * sin(2.0 * PI * (freq * 2.4) * t)
                    sampleSum += tone * envelope
                }
            }

            buffer[i] = (sampleSum * maxAmp * 0.65).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    /**
     * Cheerful rising 3-tone arpeggio for "Next" question (170ms):
     * Notes: E5 (659Hz) -> A5 (880Hz) -> C#6 (1108Hz)
     * Discrete melodic notes that sound uplifting and joyful!
     */
    private fun generateNavNextSound(): ShortArray {
        val durationMs = 170
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 26500.0

        val notes = listOf(
            Pair(0, 659.25),    // E5
            Pair(50, 880.00),   // A5
            Pair(100, 1108.73)  // C#6
        )

        for (i in 0 until numSamples) {
            val currentMs = (i * 1000) / SAMPLE_RATE
            var sampleSum = 0.0

            for ((startMs, freq) in notes) {
                if (currentMs >= startMs) {
                    val noteSampleIndex = i - (startMs * SAMPLE_RATE / 1000)
                    val noteTotalSamples = ((durationMs - startMs) * SAMPLE_RATE) / 1000
                    val noteProgress = noteSampleIndex.toDouble() / noteTotalSamples
                    val t = noteSampleIndex.toDouble() / SAMPLE_RATE

                    val attack = min(1.0, noteSampleIndex.toDouble() / (SAMPLE_RATE * 0.005))
                    val decay = exp(-noteProgress * 5.0)
                    val envelope = attack * decay

                    val tone = 0.80 * sin(2.0 * PI * freq * t) + 0.20 * sin(4.0 * PI * freq * t)
                    sampleSum += tone * envelope
                }
            }

            buffer[i] = (sampleSum * maxAmp * 0.65).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    /**
     * Gentle descending 3-tone chime for "Prev" question (170ms):
     * Notes: C#6 (1108Hz) -> A5 (880Hz) -> E5 (659Hz)
     * Smooth, musical, distinct from Next.
     */
    private fun generateNavPrevSound(): ShortArray {
        val durationMs = 170
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 26500.0

        val notes = listOf(
            Pair(0, 1108.73),  // C#6
            Pair(50, 880.00),  // A5
            Pair(100, 659.25)  // E5
        )

        for (i in 0 until numSamples) {
            val currentMs = (i * 1000) / SAMPLE_RATE
            var sampleSum = 0.0

            for ((startMs, freq) in notes) {
                if (currentMs >= startMs) {
                    val noteSampleIndex = i - (startMs * SAMPLE_RATE / 1000)
                    val noteTotalSamples = ((durationMs - startMs) * SAMPLE_RATE) / 1000
                    val noteProgress = noteSampleIndex.toDouble() / noteTotalSamples
                    val t = noteSampleIndex.toDouble() / SAMPLE_RATE

                    val attack = min(1.0, noteSampleIndex.toDouble() / (SAMPLE_RATE * 0.005))
                    val decay = exp(-noteProgress * 5.0)
                    val envelope = attack * decay

                    val tone = 0.80 * sin(2.0 * PI * freq * t) + 0.20 * sin(4.0 * PI * freq * t)
                    sampleSum += tone * envelope
                }
            }

            buffer[i] = (sampleSum * maxAmp * 0.65).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    /**
     * GRAND TRIUMPHANT VICTORY FANFARE for Test Submit (~2.2 seconds).
     * Special requirement: "નોંધ ટેસ્ટ submit mate alag lambo avaj rakhavo" and "khub maja aave"!
     * Cascading crystal chimes arpeggio in C Major:
     * C5 (523Hz) -> E5 (659Hz) -> G5 (784Hz) -> C6 (1046Hz) -> E6 (1318Hz) -> G6 (1568Hz) -> High C7 (2093Hz)
     * with long warm resonance and sparkling bell overtones.
     */
    private fun generateTestSubmitLongSound(): ShortArray {
        val durationMs = 2200
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 27500.0

        val notes = listOf(
            Triple(0, 523.25, 0.65),     // C5
            Triple(140, 659.25, 0.70),   // E5
            Triple(280, 783.99, 0.75),   // G5
            Triple(440, 1046.50, 0.85),  // C6
            Triple(600, 1318.51, 0.90),  // E6
            Triple(780, 1567.98, 0.95),  // G6
            Triple(980, 2093.00, 1.00)   // High C7 (finale sparkling chime)
        )

        for (i in 0 until numSamples) {
            val currentMs = (i * 1000) / SAMPLE_RATE
            var combinedSample = 0.0

            for ((startMs, freq, weight) in notes) {
                if (currentMs >= startMs) {
                    val noteSampleIndex = i - (startMs * SAMPLE_RATE / 1000)
                    val noteDurationMs = durationMs - startMs
                    val noteTotalSamples = (SAMPLE_RATE * noteDurationMs) / 1000
                    val noteProgress = noteSampleIndex.toDouble() / noteTotalSamples
                    val t = noteSampleIndex.toDouble() / SAMPLE_RATE

                    val attack = min(1.0, noteSampleIndex.toDouble() / (SAMPLE_RATE * 0.012))
                    // Long ringing sustain
                    val decay = exp(-noteProgress * 2.8)
                    val envelope = attack * decay

                    // Shimmering acoustic bell tone (fundamental + 2x octave + 3x harmonic)
                    val tone = 0.65 * sin(2.0 * PI * freq * t) +
                            0.25 * sin(4.0 * PI * freq * t) +
                            0.10 * sin(6.0 * PI * freq * t)

                    combinedSample += tone * weight * envelope
                }
            }

            val finalVal = (combinedSample * (maxAmp * 0.38)).coerceIn(-32767.0, 32767.0)
            buffer[i] = finalVal.toInt().toShort()
        }
        return buffer
    }

    /**
     * Warm harmonic chord for Login Success (450ms).
     * C Major triad: C5 (523Hz), E5 (659Hz), G5 (784Hz), C6 (1046Hz) with smooth swell.
     */
    private fun generateLoginSuccessSound(): ShortArray {
        val durationMs = 450
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 27000.0

        val f1 = 523.25 // C5
        val f2 = 659.25 // E5
        val f3 = 783.99 // G5
        val f4 = 1046.50 // C6

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples
            val attack = min(1.0, i.toDouble() / (SAMPLE_RATE * 0.02))
            val decay = exp(-progress * 3.2)
            val envelope = attack * decay

            val tone = 0.32 * sin(2.0 * PI * f1 * t) +
                    0.28 * sin(2.0 * PI * f2 * t) +
                    0.24 * sin(2.0 * PI * f3 * t) +
                    0.16 * sin(2.0 * PI * f4 * t)

            buffer[i] = (tone * maxAmp * envelope).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    /**
     * Sparkling ripple / wind chime for Refresh (220ms).
     */
    private fun generateRefreshSound(): ShortArray {
        val durationMs = 220
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 26000.0

        val notes = listOf(
            Pair(0, 880.00),    // A5
            Pair(40, 1046.50),  // C6
            Pair(80, 1318.51),  // E6
            Pair(120, 1760.00)  // A6
        )

        for (i in 0 until numSamples) {
            val currentMs = (i * 1000) / SAMPLE_RATE
            var sampleSum = 0.0

            for ((startMs, freq) in notes) {
                if (currentMs >= startMs) {
                    val noteSampleIndex = i - (startMs * SAMPLE_RATE / 1000)
                    val noteTotalSamples = ((durationMs - startMs) * SAMPLE_RATE) / 1000
                    val noteProgress = noteSampleIndex.toDouble() / noteTotalSamples
                    val t = noteSampleIndex.toDouble() / SAMPLE_RATE

                    val attack = min(1.0, noteSampleIndex.toDouble() / (SAMPLE_RATE * 0.006))
                    val decay = exp(-noteProgress * 5.2)
                    val envelope = attack * decay

                    val tone = 0.75 * sin(2.0 * PI * freq * t) + 0.25 * sin(4.0 * PI * freq * t)
                    sampleSum += tone * envelope
                }
            }

            buffer[i] = (sampleSum * maxAmp * 0.60).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    /**
     * Crisp wooden tick for tab switching (50ms).
     */
    private fun generateTabSwitchSound(): ShortArray {
        val durationMs = 50
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val freq = 820.0
        val maxAmp = 25000.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples
            val attack = min(1.0, i.toDouble() / (SAMPLE_RATE * 0.002))
            val decay = exp(-progress * 8.0)
            val envelope = attack * decay

            val tone = 0.80 * sin(2.0 * PI * freq * t) + 0.20 * sin(4.0 * PI * freq * t)
            buffer[i] = (tone * maxAmp * envelope).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    /**
     * Polite, soft marimba double-tap for delete / warning (220ms).
     * Low G4 (392Hz) -> Low Eb4 (311Hz) with warm acoustic dampening.
     */
    private fun generateErrorOrDeleteSound(): ShortArray {
        val durationMs = 220
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 26000.0

        val notes = listOf(
            Pair(0, 392.00),    // G4
            Pair(90, 311.13)    // Eb4
        )

        for (i in 0 until numSamples) {
            val currentMs = (i * 1000) / SAMPLE_RATE
            var sampleSum = 0.0

            for ((startMs, freq) in notes) {
                if (currentMs >= startMs) {
                    val noteSampleIndex = i - (startMs * SAMPLE_RATE / 1000)
                    val noteTotalSamples = ((durationMs - startMs) * SAMPLE_RATE) / 1000
                    val noteProgress = noteSampleIndex.toDouble() / noteTotalSamples
                    val t = noteSampleIndex.toDouble() / SAMPLE_RATE

                    val attack = min(1.0, noteSampleIndex.toDouble() / (SAMPLE_RATE * 0.008))
                    val decay = exp(-noteProgress * 4.5)
                    val envelope = attack * decay

                    val tone = 0.82 * sin(2.0 * PI * freq * t) + 0.18 * sin(4.0 * PI * freq * t)
                    sampleSum += tone * envelope
                }
            }

            buffer[i] = (sampleSum * maxAmp * 0.65).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    /**
     * Sweet bouncy double bubble-pop for toggle switches (85ms).
     */
    private fun generateSwitchToggleSound(): ShortArray {
        val durationMs = 85
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 26000.0

        val notes = listOf(
            Pair(0, 520.0),    // First pop
            Pair(40, 780.0)    // Second bright pop
        )

        for (i in 0 until numSamples) {
            val currentMs = (i * 1000) / SAMPLE_RATE
            var sampleSum = 0.0

            for ((startMs, freq) in notes) {
                if (currentMs >= startMs) {
                    val noteSampleIndex = i - (startMs * SAMPLE_RATE / 1000)
                    val noteTotalSamples = ((durationMs - startMs) * SAMPLE_RATE) / 1000
                    val noteProgress = noteSampleIndex.toDouble() / noteTotalSamples
                    val t = noteSampleIndex.toDouble() / SAMPLE_RATE

                    val attack = min(1.0, noteSampleIndex.toDouble() / (SAMPLE_RATE * 0.003))
                    val decay = exp(-noteProgress * 6.0)
                    val envelope = attack * decay

                    val tone = 0.85 * sin(2.0 * PI * freq * t) + 0.15 * sin(4.0 * PI * freq * t)
                    sampleSum += tone * envelope
                }
            }

            buffer[i] = (sampleSum * maxAmp * 0.65).toInt().coerceIn(-32767, 32767).toShort()
        }
        return buffer
    }

    // ---------------- WAV Header Encoder ----------------

    private fun pcmToWav(pcmData: ShortArray, sampleRate: Int): ByteArray {
        val totalAudioLen = pcmData.size * 2
        val totalDataLen = totalAudioLen + 36
        val byteRate = sampleRate * 1 * 2

        val header = ByteArray(44)
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // PCM
        header[21] = 0
        header[22] = 1 // Mono
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = 2
        header[33] = 0
        header[34] = 16 // 16-bit
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xff).toByte()
        header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

        val wavBytes = ByteArray(44 + totalAudioLen)
        System.arraycopy(header, 0, wavBytes, 0, 44)
        var outIdx = 44
        for (i in pcmData.indices) {
            val sample = pcmData[i].toInt()
            wavBytes[outIdx++] = (sample and 0xff).toByte()
            wavBytes[outIdx++] = ((sample shr 8) and 0xff).toByte()
        }
        return wavBytes
    }
}
