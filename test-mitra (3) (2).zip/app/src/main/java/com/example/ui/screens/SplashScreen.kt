package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.SessionManager
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    sessionManager: SessionManager,
    repository: TestMitraRepository,
    onNavigateToLogin: () -> Unit,
    onNavigateToStudentHome: () -> Unit,
    onNavigateToAdminHome: () -> Unit
) {
    val scale = remember { Animatable(0.7f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        alpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing)
        )
        scale.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing)
        )
        delay(700)

        val currentUser = sessionManager.getUser()
        if (currentUser != null && currentUser.id != null && currentUser.id > 0) {
            val currentDeviceId = sessionManager.getDeviceId()
            val sessionRes = repository.verifyUserSession(currentUser.id, currentDeviceId)
            if (sessionRes is Resource.Success) {
                val verifiedUser = sessionRes.data
                sessionManager.saveUser(verifiedUser)
                if (verifiedUser.isTeacherOrAdmin) {
                    onNavigateToAdminHome()
                } else {
                    onNavigateToStudentHome()
                }
            } else if (sessionRes is Resource.Error && !sessionRes.isNetworkError) {
                sessionManager.clearSession()
                onNavigateToLogin()
            } else {
                if (currentUser.isTeacherOrAdmin) {
                    onNavigateToAdminHome()
                } else {
                    onNavigateToStudentHome()
                }
            }
        } else {
            sessionManager.clearSession()
            onNavigateToLogin()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MitraNavyDark,
                        MitraNavyPrimary,
                        Color(0xFF0F2B48)
                    )
                )
            )
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(24.dp)
                .scale(scale.value)
                .alpha(alpha.value)
        ) {
            Surface(
                modifier = Modifier.size(150.dp),
                shape = CircleShape,
                color = Color.White,
                shadowElevation = 8.dp
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_test_mitra_logo),
                        contentDescription = "TEST MITRA Logo",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "TEST MITRA",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Smart Examination Portal",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = MitraGreen,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Online MCQ Test Platform\nSimple, Fast & Reliable Assessments",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(36.dp))

            CircularProgressIndicator(
                modifier = Modifier.size(32.dp),
                color = MitraGreen,
                strokeWidth = 3.dp
            )
        }
    }
}
