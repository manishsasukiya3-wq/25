package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = MitraNavyLight,
    onPrimary = Color.White,
    secondary = MitraGreen,
    onSecondary = Color.White,
    background = MitraNavyDark,
    surface = Color(0xFF1E293B),
    onBackground = Color.White,
    onSurface = Color.White,
    error = MitraError
)

private val LightColorScheme = lightColorScheme(
    primary = MitraNavyPrimary,
    onPrimary = Color.White,
    secondary = MitraGreen,
    onSecondary = Color.White,
    background = MitraBgLight,
    surface = MitraCardBg,
    onBackground = MitraTextPrimary,
    onSurface = MitraTextPrimary,
    error = MitraError
)

@Composable
fun TestMitraTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    // Strictly enforce LightColorScheme throughout the app regardless of system dark mode
    val colorScheme = LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                view.isForceDarkAllowed = false
            }
            val window = (view.context as? Activity)?.window
            if (window != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    window.isStatusBarContrastEnforced = false
                    window.isNavigationBarContrastEnforced = false
                    window.decorView.isForceDarkAllowed = false
                }
                window.statusBarColor = android.graphics.Color.TRANSPARENT
                window.navigationBarColor = android.graphics.Color.TRANSPARENT
                val insetsController = WindowCompat.getInsetsController(window, view)
                // Set status bar icons to light (white) so they are crisp & readable over the dark navy top bar
                insetsController.isAppearanceLightStatusBars = false
                // Navigation bar is light, so navigation icons should be dark
                insetsController.isAppearanceLightNavigationBars = true
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    TestMitraTheme(darkTheme = false, dynamicColor = false, content = content)
}
